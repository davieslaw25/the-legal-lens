import React from "react";

export default function App() {
  const services = [
    {
      title: "Virtual Legal Support",
      text: "Responsive legal support delivered remotely for clients across Commonwealth jurisdictions, with a focus on clarity, structure, and practical outcomes.",
      icon: "⚖️",
    },
    {
      title: "Legal Tutoring & Coaching",
      text: "Targeted tutoring, skills coaching, and legal learning support for law students and developing professionals.",
      icon: "📚",
    },
    {
      title: "Corporate Legal Support",
      text: "Advisory support for businesses, legal teams, and professionals seeking dependable legal assistance in a virtual format.",
      icon: "🏛️",
    },
    {
      title: "Law Firm Support",
      text: "Flexible support for lawyers and firms, including legal research, drafting assistance, and workflow reinforcement.",
      icon: "🖋️",
    },
    {
      title: "Legal Research Assistance",
      text: "Well-structured research support for academic, professional, and practice-related legal work.",
      icon: "🔎",
    },
    {
      title: "Resources / Store",
      text: "Practical legal materials, templates, and study tools made available through Gumroad for easy access and purchase. Visit our store to explore and buy resources instantly.",
      icon: "🛒",
    },
  ];

  const blogPosts = [
    {
      title: "Understanding Contract Risk in Modern Business",
      tag: "Corporate Law",
      excerpt:
        "A practical overview of common contract risks and how legal support can help organizations spot issues early.",
    },
    {
      title: "Top Legal Research Strategies for Law Students",
      tag: "Student Corner",
      excerpt:
        "Sharper legal research habits can improve academic performance and build stronger professional foundations.",
    },
    {
      title: "How Virtual Legal Support Is Changing Legal Service Delivery",
      tag: "Legal Insights",
      excerpt:
        "Why remote-first legal support is becoming a smart model for lawyers, firms, corporates, and students alike.",
    },
  ];

  const testimonials = [
    {
      quote:
        "The Legal Lens delivers clarity and precision in complex legal matters. The support feels practical, responsive, and globally relevant.",
      name: "Client Testimonial",
    },
    {
      quote:
        "A reliable legal support platform for professionals and students alike. The guidance is structured, accessible, and genuinely helpful.",
      name: "Professional Testimonial",
    },
    {
      quote:
        "The blend of legal support, tutoring, and resources makes The Legal Lens stand out as a modern legal hub.",
      name: "Student Testimonial",
    },
  ];

  const nav = ["Home", "About", "Services", "Blog", "Contact"];

  const scrollToId = (id) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const sectionTitle = (eyebrow, title, text) => (
    <div className="max-w-3xl mb-12">
      <p className="text-sm font-semibold uppercase tracking-[0.25em] text-emerald-700 mb-3">{eyebrow}</p>
      <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">{title}</h2>
      <p className="text-slate-600 text-lg leading-8">{text}</p>
    </div>
  );

  return (
    <div className="min-h-screen bg-white text-slate-900">
      <header className="sticky top-0 z-50 border-b border-emerald-100/80 bg-white/95 backdrop-blur">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center justify-between h-20 gap-4">
            <button onClick={() => scrollToId("home")} className="flex items-center gap-4 text-left min-w-0">
              <img src="/logo.png" alt="The Legal Lens Logo" className="h-12 w-12 rounded-xl object-contain shrink-0" />
              <div className="min-w-0">
                <div className="font-bold text-lg tracking-tight truncate">The Legal Lens</div>
                <div className="text-sm text-slate-500 truncate">Legal Support • Tutoring • Resources</div>
              </div>
            </button>

            <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-700">
              {nav.map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToId(item.toLowerCase())}
                  className="hover:text-emerald-700 transition-colors"
                >
                  {item}
                </button>
              ))}
            </nav>

            <div className="flex items-center gap-3 shrink-0">
              <a
                href="https://wa.me/254752117688"
                target="_blank"
                rel="noreferrer"
                className="hidden sm:inline-flex items-center rounded-2xl border border-emerald-200 px-4 py-2 text-sm font-semibold text-emerald-800 hover:bg-emerald-50 transition"
              >
                WhatsApp
              </a>
              <button
                onClick={() => scrollToId("contact")}
                className="inline-flex items-center rounded-2xl bg-emerald-700 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-emerald-200 hover:bg-emerald-800 transition"
              >
                Book a Consultation
              </button>
            </div>
          </div>
        </div>
      </header>

      <main>
        <section id="home" className="relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,_rgba(16,185,129,0.13),_transparent_35%),radial-gradient(circle_at_bottom_right,_rgba(5,150,105,0.10),_transparent_30%)]" />
          <div className="relative max-w-7xl mx-auto px-6 lg:px-8 pt-16 pb-24 md:pt-24 md:pb-28">
            <div className="grid lg:grid-cols-2 gap-14 items-center">
              <div>
                <div className="inline-flex items-center gap-2 rounded-full border border-emerald-200 bg-emerald-50 px-4 py-2 text-sm text-emerald-800 font-medium mb-6">
                  Global reach with a Commonwealth focus
                </div>
                <h1 className="text-5xl md:text-6xl font-bold tracking-tight text-slate-950 leading-[1.05]">
                  Your all-in-one hub for legal support and success.
                </h1>
                <p className="mt-6 text-lg md:text-xl text-slate-600 leading-8 max-w-2xl">
                  The Legal Lens helps lawyers, law firms, corporates, and law students access high-quality virtual legal support, tutoring, and practical legal resources from one modern platform.
                </p>

                <div className="mt-10 flex flex-col sm:flex-row gap-4">
                  <button
                    onClick={() => scrollToId("contact")}
                    className="inline-flex items-center justify-center rounded-2xl bg-emerald-700 px-6 py-4 text-base font-semibold text-white shadow-xl shadow-emerald-200 hover:bg-emerald-800 transition"
                  >
                    Book a Consultation
                  </button>
                  <a
                    href="https://wa.me/254752117688"
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center rounded-2xl border border-slate-300 px-6 py-4 text-base font-semibold text-slate-700 hover:border-emerald-300 hover:text-emerald-800 hover:bg-emerald-50 transition"
                  >
                    Chat on WhatsApp
                  </a>
                </div>

                <div className="mt-10 grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {[
                    "Virtual-first legal support",
                    "Flexible pricing — contact for quote",
                    "Services for professionals and students",
                  ].map((item) => (
                    <div key={item} className="rounded-2xl border border-slate-200 bg-white/90 p-4 shadow-sm">
                      <p className="text-sm font-medium text-slate-700">{item}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="relative">
                <div className="rounded-[2rem] border border-emerald-100 bg-white p-8 shadow-2xl shadow-emerald-100">
                  <div className="flex items-start justify-between gap-4 mb-8">
                    <div>
                      <p className="text-sm uppercase tracking-[0.2em] text-emerald-700 font-semibold">The Legal Lens</p>
                      <h3 className="text-2xl font-bold mt-2">Professional. Practical. Global.</h3>
                    </div>
                    <img src="/logo.png" alt="The Legal Lens Logo" className="h-14 w-14 rounded-xl object-contain" />
                  </div>

                  <div className="space-y-4">
                    {[
                      "Virtual legal support for lawyers, firms, and corporates",
                      "Tutoring and structured support for law students",
                      "Legal resources and materials available via Gumroad",
                      "Commonwealth-focused, globally accessible service delivery",
                    ].map((item) => (
                      <div key={item} className="flex items-start gap-3 rounded-2xl bg-slate-50 p-4">
                        <div className="mt-1 h-6 w-6 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center text-sm">
                          ✓
                        </div>
                        <p className="text-slate-700 leading-7">{item}</p>
                      </div>
                    ))}
                  </div>

                  <div className="mt-8 rounded-2xl bg-slate-900 p-6 text-white">
                    <p className="text-sm text-emerald-300 font-semibold uppercase tracking-[0.2em]">Lead Contact</p>
                    <p className="text-xl font-semibold mt-2">Davies Macharia</p>
                    <p className="text-slate-300 mt-1">Team Lead • Virtual / Global Services</p>
                    <div className="mt-4 text-sm text-slate-300 space-y-1">
                      <p>+254 752 117688</p>
                      <p>legallens889@gmail.com</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-slate-50 border-y border-slate-100">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            {sectionTitle(
              "Why choose us",
              "Legal support built for a modern global audience.",
              "We combine professional legal support, educational guidance, and practical resources in one accessible platform designed for real-world use."
            )}

            <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-6">
              {[
                {
                  title: "Commonwealth Reach",
                  text: "Positioned to support clients and learners across multiple Commonwealth jurisdictions.",
                },
                {
                  title: "Virtual Convenience",
                  text: "Access support, consultation, and learning without geographic limits.",
                },
                {
                  title: "Practical Legal Insight",
                  text: "Clear, structured, and useful guidance designed to help you move forward.",
                },
                {
                  title: "Multi-Audience Support",
                  text: "Built for lawyers, firms, corporates, and law students on one platform.",
                },
              ].map((item) => (
                <div key={item.title} className="rounded-3xl bg-white border border-slate-200 p-6 shadow-sm">
                  <h3 className="text-xl font-semibold mb-3">{item.title}</h3>
                  <p className="text-slate-600 leading-7">{item.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="about" className="py-24">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-16 items-start">
              <div>
                {sectionTitle(
                  "About",
                  "A legal platform designed to simplify support, learning, and access.",
                  "The Legal Lens is a modern legal support brand focused on helping clients navigate legal needs with confidence. Through virtual service delivery, tutoring, and curated legal materials, the platform serves a broad audience with a practical and professional approach."
                )}
                <div className="space-y-6 text-slate-600 leading-8 text-lg">
                  <p>
                    Our model is built around accessibility, responsiveness, and quality. Whether the need is professional legal support, student guidance, or practical legal tools, The Legal Lens is structured to deliver value in a clear and reliable format.
                  </p>
                  <p>
                    With a global outlook and particular relevance to Commonwealth jurisdictions, the platform is designed for a diverse audience that values legal precision, convenience, and modern service delivery.
                  </p>
                </div>
              </div>

              <div className="grid gap-6">
                <div className="rounded-[2rem] bg-emerald-700 p-8 text-white shadow-2xl shadow-emerald-100">
                  <p className="text-sm uppercase tracking-[0.25em] text-emerald-100 font-semibold">Team Lead</p>
                  <h3 className="text-3xl font-bold mt-3">Davies Macharia</h3>
                  <p className="mt-5 text-emerald-50 leading-8">
                    I am a Kenyan Lawyer and aspiring Solicitor (UK), currently serving as a Legal Officer at IYF. With a strong foundation in legal practice and a forward-looking approach to the profession, I am committed to delivering clear, practical, and accessible legal solutions. As Team Lead of The Legal Lens, I bring together legal insight, education, and innovation to support students, professionals, and clients navigating an increasingly complex legal landscape. My work is driven by a focus on clarity, impact, and continuous growth—bridging the gap between legal theory and real-world application.
                  </p>
                </div>

                <div className="grid sm:grid-cols-2 gap-6">
                  <div className="rounded-3xl border border-slate-200 p-6">
                    <h4 className="font-semibold text-xl mb-3">Mission</h4>
                    <p className="text-slate-600 leading-7">
                      To provide accessible, high-quality legal support and education that empowers professionals, organizations, and students.
                    </p>
                  </div>
                  <div className="rounded-3xl border border-slate-200 p-6">
                    <h4 className="font-semibold text-xl mb-3">Vision</h4>
                    <p className="text-slate-600 leading-7">
                      To become a trusted global hub for legal support, legal learning, and modern legal resources.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="services" className="py-24 bg-slate-50 border-y border-slate-100">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            {sectionTitle(
              "Services",
              "Structured solutions for legal professionals, businesses, and law students.",
              "Our service offering blends legal support, tutoring, research, and digital resources in a flexible model that meets modern legal and educational needs."
            )}

            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
              {services.map((service) => (
                <div
                  key={service.title}
                  className="rounded-[2rem] bg-white border border-slate-200 p-7 shadow-sm hover:shadow-lg transition-shadow"
                >
                  <div className="h-14 w-14 rounded-2xl bg-emerald-50 text-2xl flex items-center justify-center mb-5">
                    {service.icon}
                  </div>
                  <h3 className="text-2xl font-semibold mb-3">{service.title}</h3>
                  <p className="text-slate-600 leading-7">{service.text}</p>
                  {service.title === "Resources / Store" && (
                    <a
                      href="https://gumroad.com/products"
                      target="_blank"
                      rel="noreferrer"
                      className="inline-block mt-4 text-emerald-700 font-semibold hover:underline"
                    >
                      Visit Store →
                    </a>
                  )}
                </div>
              ))}
            </div>

            <div className="mt-12 rounded-[2rem] bg-slate-900 p-8 md:p-10 text-white flex flex-col md:flex-row md:items-center md:justify-between gap-6">
              <div>
                <p className="text-emerald-300 uppercase tracking-[0.2em] text-sm font-semibold">Consultation</p>
                <h3 className="text-3xl font-bold mt-2">Flexible pricing. Contact for quote.</h3>
                <p className="text-slate-300 mt-3 max-w-2xl leading-7">
                  Need tailored support, tutoring, or resources? Reach out for a consultation and receive a service path aligned to your needs.
                </p>
              </div>
              <button
                onClick={() => scrollToId("contact")}
                className="inline-flex items-center justify-center rounded-2xl bg-emerald-600 px-6 py-4 text-base font-semibold text-white hover:bg-emerald-500 transition"
              >
                Contact for Quote
              </button>
            </div>
          </div>
        </section>

        <section id="blog" className="py-24">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            {sectionTitle(
              "Blog",
              "Legal insights, practical guidance, and resource-driven thinking.",
              "Use this section to publish articles that build authority, educate your audience, and support your services and Gumroad resource offering."
            )}

            <div className="grid lg:grid-cols-3 gap-6">
              {blogPosts.map((post) => (
                <article
                  key={post.title}
                  className="rounded-[2rem] border border-slate-200 p-7 shadow-sm hover:shadow-lg transition-shadow bg-white"
                >
                  <span className="inline-flex rounded-full bg-emerald-50 px-3 py-1 text-sm font-semibold text-emerald-800 mb-4">
                    {post.tag}
                  </span>
                  <h3 className="text-2xl font-semibold leading-tight mb-3">{post.title}</h3>
                  <p className="text-slate-600 leading-7">{post.excerpt}</p>
                  <button className="mt-6 text-emerald-700 font-semibold hover:text-emerald-800 transition-colors">
                    Read more →
                  </button>
                </article>
              ))}
            </div>

            <div className="mt-12 grid md:grid-cols-2 gap-6">
              <div className="rounded-[2rem] border border-emerald-100 bg-emerald-50 p-8">
                <p className="text-sm uppercase tracking-[0.2em] text-emerald-700 font-semibold">Resources integration</p>
                <h3 className="text-2xl font-bold mt-3">Turn blog readers into resource buyers.</h3>
                <p className="mt-4 text-slate-700 leading-7">
                  Articles can naturally guide visitors toward practical legal templates, study materials, and legal guides available through your Gumroad store.
                </p>
              </div>
              <div className="rounded-[2rem] border border-slate-200 p-8 bg-white">
                <p className="text-sm uppercase tracking-[0.2em] text-slate-500 font-semibold">Suggested categories</p>
                <div className="mt-4 flex flex-wrap gap-3">
                  {["Legal Insights", "Corporate Law Updates", "Student Corner", "Practical Law Guides", "Case Analysis"].map(
                    (category) => (
                      <span
                        key={category}
                        className="rounded-full border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700"
                      >
                        {category}
                      </span>
                    )
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-24 bg-slate-50 border-y border-slate-100">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            {sectionTitle(
              "Testimonials",
              "Trusted impressions from a modern legal audience.",
              "These are polished placeholders for now and can be replaced with real testimonials as your website grows."
            )}

            <div className="grid lg:grid-cols-3 gap-6">
              {testimonials.map((testimonial) => (
                <div key={testimonial.quote} className="rounded-[2rem] bg-white border border-slate-200 p-8 shadow-sm">
                  <p className="text-4xl text-emerald-600 leading-none">“</p>
                  <p className="mt-4 text-slate-700 leading-8">{testimonial.quote}</p>
                  <p className="mt-6 font-semibold text-slate-900">{testimonial.name}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="contact" className="py-24">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12 items-start">
              <div>
                {sectionTitle(
                  "Contact",
                  "Book a consultation or request a quote.",
                  "The Legal Lens operates on a virtual and global model, making it easy to connect from anywhere. Reach out for legal support, tutoring, collaboration, or resource inquiries."
                )}

                <div className="space-y-5 text-lg text-slate-700">
                  <div className="rounded-3xl border border-slate-200 p-5">
                    <p className="text-sm uppercase tracking-[0.2em] text-slate-500 font-semibold mb-2">Phone / WhatsApp</p>
                    <a href="tel:+254752117688" className="font-semibold hover:text-emerald-700 transition-colors">
                      +254 752 117688
                    </a>
                  </div>
                  <div className="rounded-3xl border border-slate-200 p-5">
                    <p className="text-sm uppercase tracking-[0.2em] text-slate-500 font-semibold mb-2">Email</p>
                    <a href="mailto:legallens889@gmail.com" className="font-semibold hover:text-emerald-700 transition-colors">
                      legallens889@gmail.com
                    </a>
                  </div>
                  <div className="rounded-3xl border border-slate-200 p-5">
                    <p className="text-sm uppercase tracking-[0.2em] text-slate-500 font-semibold mb-2">Coverage</p>
                    <p className="font-semibold">Virtual / Global Services</p>
                    <p className="text-slate-600 mt-1">With a strong Commonwealth-oriented focus.</p>
                  </div>
                </div>

                <div className="mt-8 flex flex-wrap gap-4">
                  <a
                    href="https://wa.me/254752117688"
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center rounded-2xl bg-emerald-700 px-6 py-4 text-base font-semibold text-white shadow-lg shadow-emerald-100 hover:bg-emerald-800 transition"
                  >
                    WhatsApp Now
                  </a>
                  <a
                    href="mailto:legallens889@gmail.com"
                    className="inline-flex items-center justify-center rounded-2xl border border-slate-300 px-6 py-4 text-base font-semibold text-slate-700 hover:bg-slate-50 transition"
                  >
                    Send Email
                  </a>
                </div>
              </div>

              <div className="rounded-[2rem] border border-slate-200 bg-white p-8 shadow-xl shadow-slate-100">
                <h3 className="text-2xl font-bold mb-6">Quick Contact Form</h3>
                <form className="space-y-5" onSubmit={(e) => e.preventDefault()}>
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Name</label>
                    <input
                      className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-emerald-500"
                      placeholder="Your name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Email</label>
                    <input
                      type="email"
                      className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-emerald-500"
                      placeholder="you@example.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Service Needed</label>
                    <select className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-emerald-500 bg-white">
                      <option>Virtual Legal Support</option>
                      <option>Legal Tutoring & Coaching</option>
                      <option>Corporate Legal Support</option>
                      <option>Law Firm Support</option>
                      <option>Legal Research Assistance</option>
                      <option>Resources / Store Inquiry</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Message</label>
                    <textarea
                      rows="5"
                      className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-emerald-500"
                      placeholder="Tell us how we can help"
                    />
                  </div>
                  <button className="w-full rounded-2xl bg-slate-900 px-5 py-4 text-base font-semibold text-white hover:bg-slate-800 transition">
                    Submit Inquiry
                  </button>
                </form>
                <p className="text-sm text-slate-500 mt-4">
                  This demo form is ready for connection to email, Formspark, Formspree, or your preferred form handler.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-slate-950 text-white">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="grid lg:grid-cols-3 gap-10 items-start">
              <div className="lg:col-span-2">
                <p className="text-sm uppercase tracking-[0.2em] text-emerald-300 font-semibold">Disclaimer</p>
                <h3 className="text-3xl font-bold mt-3">Important legal notice</h3>
                <p className="mt-5 text-slate-300 leading-8 max-w-4xl">
                  The information provided on this website is for general informational and educational purposes only and does not constitute legal advice. Engagement with The Legal Lens does not create a lawyer-client relationship unless expressly agreed. Visitors should obtain formal legal advice for specific matters and decisions.
                </p>
              </div>
              <div className="rounded-[2rem] border border-white/10 bg-white/5 p-6">
                <p className="text-sm uppercase tracking-[0.2em] text-emerald-300 font-semibold">Privacy</p>
                <p className="mt-3 text-slate-300 leading-7">
                  Information submitted through the website should be used only for communication and service-related follow-up. A full privacy notice can be added later.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-10">
          <div className="flex flex-col lg:flex-row gap-6 lg:items-center lg:justify-between">
            <div>
              <h4 className="font-bold text-xl">The Legal Lens</h4>
              <p className="text-slate-600 mt-2">Your All-in-One Hub for Legal Support and Success</p>
            </div>

            <div className="flex flex-wrap gap-5 text-sm font-medium text-slate-700">
              {nav.map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToId(item.toLowerCase())}
                  className="hover:text-emerald-700 transition-colors"
                >
                  {item}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-4 text-sm text-slate-600">
              <a href="https://facebook.com" target="_blank" rel="noreferrer" className="hover:text-emerald-700 transition-colors">
                Meta
              </a>
              <a href="https://x.com/thesqebrief" target="_blank" rel="noreferrer" className="hover:text-emerald-700 transition-colors">
                X
              </a>
              <a href="https://instagram.com" target="_blank" rel="noreferrer" className="hover:text-emerald-700 transition-colors">
                Instagram
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
